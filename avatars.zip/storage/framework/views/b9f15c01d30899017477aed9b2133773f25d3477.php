

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header">Absen Kelas</div>
        <div class="card-body">
            <div class="" style="overflow: scroll;height: 600px;">
                <?php
                $no = 1;
                ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $rombel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $query = \App\Models\Absen::where(['kode_rombel'=> $row->kode_rombel, 'tanggal_absen'=> date('Y-m-d')])->count();
                    ?>
                    <?php if($query<=0): ?> <li class="list-group-item"><?php echo e($row->rombel); ?> <a href="<?php echo e(route('guru.detailabsensi',$row->kode_rombel)); ?>" class="btn btn-primary float-end">Absen</a></li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class=" card-footer">
        </div>

    </div>

</div>

<nav class="navbar navbar-dark bg-info navbar-expand d-md-none d-lg-none d-xl-none fixed-bottom">
    <ul class="navbar-nav nav-justified w-100">
        <li class="nav-item">
            <a href="<?php echo e(url('guru/dashboard')); ?>" class="nav-link"><i class="bi bi-house-door-fill"></i></a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('guru/absensi')); ?>" class="nav-link"><i class="bi bi-bookmark-star-fill"></i></a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('guru/profil')); ?>" class="nav-link active"><i class="bi bi-person-circle"></i></a>
        </li>
    </ul>
</nav>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WINDOWS 10\avatars\resources\views/guru/absensi.blade.php ENDPATH**/ ?>